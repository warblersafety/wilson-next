/* @ds-bundle: {"format":4,"namespace":"WarblerSafetyDesignSystem_192289","components":[{"name":"Eyebrow","sourcePath":"components/brand/Eyebrow.jsx"},{"name":"Logo","sourcePath":"components/brand/Logo.jsx"},{"name":"Pullquote","sourcePath":"components/brand/Pullquote.jsx"},{"name":"SectionHeading","sourcePath":"components/brand/SectionHeading.jsx"},{"name":"NoticeCard","sourcePath":"components/content/NoticeCard.jsx"},{"name":"NumberedStep","sourcePath":"components/content/NumberedStep.jsx"},{"name":"PersonCard","sourcePath":"components/content/PersonCard.jsx"},{"name":"ProductRow","sourcePath":"components/content/ProductRow.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"ProgressBar","sourcePath":"components/core/ProgressBar.jsx"},{"name":"TabSwitch","sourcePath":"components/core/TabSwitch.jsx"},{"name":"TextLink","sourcePath":"components/core/TextLink.jsx"},{"name":"FieldLabel","sourcePath":"components/forms/FieldLabel.jsx"},{"name":"SelectField","sourcePath":"components/forms/SelectField.jsx"},{"name":"TextArea","sourcePath":"components/forms/TextArea.jsx"},{"name":"TextField","sourcePath":"components/forms/TextField.jsx"},{"name":"ChatBubble","sourcePath":"components/voice/ChatBubble.jsx"},{"name":"DoneToast","sourcePath":"components/voice/DoneToast.jsx"},{"name":"MicMeter","sourcePath":"components/voice/MicMeter.jsx"},{"name":"FormPaper","sourcePath":"ui_kits/voice_intake/FormPaper.jsx"},{"name":"IntakePanel","sourcePath":"ui_kits/voice_intake/IntakePanel.jsx"},{"name":"VoiceIntake","sourcePath":"ui_kits/voice_intake/VoiceIntake.jsx"},{"name":"AboutSection","sourcePath":"ui_kits/website/AboutSection.jsx"},{"name":"AfterCallSection","sourcePath":"ui_kits/website/AfterCallSection.jsx"},{"name":"ContactSection","sourcePath":"ui_kits/website/ContactSection.jsx"},{"name":"DemoSection","sourcePath":"ui_kits/website/DemoSection.jsx"},{"name":"HeroSection","sourcePath":"ui_kits/website/HeroSection.jsx"},{"name":"MissionSection","sourcePath":"ui_kits/website/MissionSection.jsx"},{"name":"ProductsSection","sourcePath":"ui_kits/website/ProductsSection.jsx"},{"name":"SiteFooter","sourcePath":"ui_kits/website/SiteFooter.jsx"},{"name":"SiteHeader","sourcePath":"ui_kits/website/SiteHeader.jsx"},{"name":"WarblerSite","sourcePath":"ui_kits/website/WarblerSite.jsx"}],"sourceHashes":{"components/brand/Eyebrow.jsx":"52d8cc339bf8","components/brand/Logo.jsx":"1781b7a25e6c","components/brand/Pullquote.jsx":"e0cebce13630","components/brand/SectionHeading.jsx":"d0a40ec6a373","components/content/NoticeCard.jsx":"2e9acd66083b","components/content/NumberedStep.jsx":"d65950ab3c93","components/content/PersonCard.jsx":"fe8f0179c7bb","components/content/ProductRow.jsx":"656175988279","components/core/Button.jsx":"b796803528bf","components/core/Icon.jsx":"2b9184257451","components/core/ProgressBar.jsx":"8fbe744818c8","components/core/TabSwitch.jsx":"717370aa99ec","components/core/TextLink.jsx":"24360be7b45e","components/forms/FieldLabel.jsx":"d716725b8c68","components/forms/SelectField.jsx":"5db270e83de4","components/forms/TextArea.jsx":"7817106cdfd4","components/forms/TextField.jsx":"26fd609515aa","components/voice/ChatBubble.jsx":"790290bff346","components/voice/DoneToast.jsx":"ec0ee8970267","components/voice/MicMeter.jsx":"ffffb5c8563d","ui_kits/voice_intake/FormPaper.jsx":"34fac47b45b4","ui_kits/voice_intake/IntakePanel.jsx":"f83427cdad4a","ui_kits/voice_intake/VoiceIntake.jsx":"e31e79635fcc","ui_kits/website/AboutSection.jsx":"2811e0d053c2","ui_kits/website/AfterCallSection.jsx":"824c91d4a394","ui_kits/website/ContactSection.jsx":"9940fed4c0f7","ui_kits/website/DemoSection.jsx":"c445fb4938af","ui_kits/website/HeroSection.jsx":"f3cf7cf7973d","ui_kits/website/MissionSection.jsx":"ea23318eda15","ui_kits/website/ProductsSection.jsx":"9246e634a885","ui_kits/website/SiteFooter.jsx":"f4617ef8e025","ui_kits/website/SiteHeader.jsx":"afff0322f026","ui_kits/website/WarblerSite.jsx":"e7c835d89fcf"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.WarblerSafetyDesignSystem_192289 = window.WarblerSafetyDesignSystem_192289 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/brand/Eyebrow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const eyebrowTones = {
  gold: {
    color: "var(--text-eyebrow)",
    fontSize: "var(--type-eyebrow-size)",
    fontWeight: 600
  },
  neutral: {
    color: "var(--text-eyebrow-neutral)",
    fontSize: "var(--type-eyebrow-size)",
    fontWeight: 600
  },
  onDark: {
    color: "var(--accent)",
    fontSize: "var(--type-eyebrow-size-dark)",
    fontWeight: 700
  }
};

/* The only uppercase text in the system. One per section, directly above the heading. */
function Eyebrow({
  children,
  tone = "gold",
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("p", _extends({
    style: {
      letterSpacing: "var(--type-eyebrow-track)",
      textTransform: "uppercase",
      margin: 0,
      ...eyebrowTones[tone],
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Eyebrow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Eyebrow.jsx", error: String((e && e.message) || e) }); }

// components/brand/Logo.jsx
try { (() => {
/* The lockup is always mark + two words, and only the second word takes colour. */
function Logo({
  markSrc = "assets/logo-warbler-mark.png",
  height = 32,
  wordSize = 19,
  accent = "var(--gold-600)",
  tone = "light",
  showWordmark = true,
  href,
  style,
  ...rest
}) {
  const ink = tone === "onDark" ? "var(--white)" : "var(--navy-900)";
  const inner = [React.createElement("img", {
    key: "m",
    src: markSrc,
    alt: showWordmark ? "" : "Warbler Safety",
    style: {
      height: height,
      width: "auto",
      display: "block"
    }
  }), showWordmark ? React.createElement("span", {
    key: "w",
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: wordSize,
      letterSpacing: "var(--type-wordmark-track)",
      whiteSpace: "nowrap",
      color: ink
    }
  }, "Warbler ", React.createElement("span", {
    style: {
      color: accent
    }
  }, "Safety")) : null];
  const s = {
    display: "flex",
    alignItems: "center",
    gap: height > 28 ? 10 : 9,
    textDecoration: "none",
    color: ink,
    ...style
  };
  if (href) return React.createElement("a", {
    href: href,
    style: s,
    ...rest
  }, inner);
  return React.createElement("div", {
    style: s,
    ...rest
  }, inner);
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Logo.jsx", error: String((e && e.message) || e) }); }

// components/brand/Pullquote.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* One per page, maximum. The yellow rule is the only place a left border accent appears. */
function Pullquote({
  children,
  tone = "light",
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("p", _extends({
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 600,
      fontSize: "var(--type-pullquote-size)",
      lineHeight: "var(--type-pullquote-line)",
      letterSpacing: "var(--type-pullquote-track)",
      color: tone === "onDark" ? "var(--white)" : "var(--navy-900)",
      margin: 0,
      maxWidth: "23em",
      paddingLeft: "clamp(16px,2.5vw,24px)",
      borderLeft: "var(--border-accent-width) solid var(--accent)",
      textWrap: "balance",
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Pullquote });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Pullquote.jsx", error: String((e && e.message) || e) }); }

// components/brand/SectionHeading.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const headingLevels = {
  h1: {
    fontSize: "var(--type-h1-size)",
    lineHeight: "var(--type-h1-line)",
    letterSpacing: "var(--type-h1-track)",
    fontWeight: 800
  },
  lead: {
    fontSize: "var(--type-h2-lead-size)",
    lineHeight: "var(--type-h2-lead-line)",
    letterSpacing: "var(--type-h2-lead-track)",
    fontWeight: 700
  },
  h2: {
    fontSize: "var(--type-h2-size)",
    lineHeight: "var(--type-h2-line)",
    letterSpacing: "var(--type-h2-track)",
    fontWeight: 700
  }
};
function SectionHeading({
  children,
  level = "h2",
  tone = "light",
  as,
  maxWidth = "15em",
  center = false,
  style,
  ...rest
}) {
  const Tag = as || (level === "h1" ? "h1" : "h2");
  return /*#__PURE__*/React.createElement(Tag, _extends({
    style: {
      fontFamily: "var(--font-display)",
      color: tone === "onDark" ? "var(--white)" : "var(--navy-900)",
      margin: 0,
      maxWidth: maxWidth,
      textWrap: "balance",
      marginLeft: center ? "auto" : undefined,
      marginRight: center ? "auto" : undefined,
      textAlign: center ? "center" : undefined,
      ...headingLevels[level],
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { SectionHeading });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/SectionHeading.jsx", error: String((e && e.message) || e) }); }

// components/content/NumberedStep.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function NumberedStep({
  number,
  title,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: style
  }, rest), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 800,
      fontSize: 13,
      letterSpacing: ".06em",
      color: "var(--text-eyebrow)",
      margin: "0 0 12px"
    }
  }, number), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: "var(--type-h3-size)",
      letterSpacing: "var(--type-h3-track)",
      color: "var(--navy-900)",
      margin: "0 0 8px"
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--type-small-size)",
      lineHeight: "var(--type-small-line)",
      color: "var(--text-muted)",
      margin: 0,
      textWrap: "pretty"
    }
  }, children));
}
Object.assign(__ds_scope, { NumberedStep });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/NumberedStep.jsx", error: String((e && e.message) || e) }); }

// components/content/PersonCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Founders on navy: 56px round photo, display name, yellow role line, grey bio. */
function PersonCard({
  photo,
  name,
  role,
  children,
  tone = "onDark",
  style,
  ...rest
}) {
  const dark = tone === "onDark";
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      gap: 16,
      alignItems: "flex-start",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("img", {
    src: photo,
    alt: "",
    style: {
      width: 56,
      height: 56,
      borderRadius: "var(--radius-circle)",
      objectFit: "cover",
      border: "var(--border-width) solid " + (dark ? "var(--border-on-dark-strong)" : "var(--border-hairline)"),
      flex: "none",
      display: "block"
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: 16,
      color: dark ? "var(--white)" : "var(--navy-900)",
      margin: "0 0 3px"
    }
  }, name), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--type-label-size)",
      fontWeight: 600,
      color: dark ? "var(--accent)" : "var(--text-eyebrow)",
      margin: "0 0 7px"
    }
  }, role), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 14,
      lineHeight: 1.55,
      color: dark ? "var(--text-on-dark-muted)" : "var(--text-muted)",
      margin: 0,
      textWrap: "pretty"
    }
  }, children)));
}
Object.assign(__ds_scope, { PersonCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/PersonCard.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const buttonSizes = {
  md: {
    minHeight: "var(--hit-min)",
    padding: "0 18px",
    borderRadius: "var(--radius-sm)",
    fontSize: "var(--type-ui-size)",
    fontWeight: 600
  },
  form: {
    padding: "13px 18px",
    borderRadius: "var(--radius-md)",
    fontSize: "var(--type-small-size)",
    fontWeight: 600
  },
  chip: {
    padding: "7px 12px",
    borderRadius: "var(--radius-sm)",
    fontSize: "11.5px",
    fontWeight: 700
  }
};
const buttonTones = {
  primary: {
    background: "var(--navy-900)",
    color: "var(--white)"
  },
  accent: {
    background: "var(--accent)",
    color: "var(--navy-900)"
  }
};
function Button({
  children,
  tone = "primary",
  size = "md",
  href,
  block = false,
  type = "button",
  disabled = false,
  style,
  ...rest
}) {
  const s = {
    display: block ? "flex" : "inline-flex",
    width: block ? "100%" : undefined,
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    fontFamily: "var(--font-body)",
    textDecoration: "none",
    border: "none",
    whiteSpace: "nowrap",
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.45 : 1,
    ...buttonSizes[size],
    ...buttonTones[tone],
    ...style
  };
  if (href && !disabled) return /*#__PURE__*/React.createElement("a", _extends({
    className: "wb-btn",
    href: href,
    style: s
  }, rest), children);
  return /*#__PURE__*/React.createElement("button", _extends({
    className: "wb-btn",
    type: type,
    disabled: disabled,
    style: s
  }, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Lucide 1.27.0, drawn the way the site draws it: a data-lucide placeholder that
   lucide.createIcons() swaps for an inline SVG. Load lucide before mounting. */
function Icon({
  name,
  size = 18,
  color,
  style,
  ...rest
}) {
  React.useEffect(() => {
    const draw = () => {
      if (window.lucide && window.lucide.createIcons) window.lucide.createIcons();
    };
    draw();
    const a = setTimeout(draw, 200),
      b = setTimeout(draw, 800);
    return () => {
      clearTimeout(a);
      clearTimeout(b);
    };
  });
  return /*#__PURE__*/React.createElement("i", _extends({
    "data-lucide": name,
    style: {
      width: size,
      height: size,
      color: color,
      display: "inline-flex",
      flex: "none",
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/content/NoticeCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* The only card shape in the system: white on cream, 1px warm border, 14px radius,
   navy icon square with a yellow glyph. No shadow. */
function NoticeCard({
  icon = "shield-off",
  title,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      flexWrap: "wrap",
      alignItems: "flex-start",
      gap: "clamp(16px,3vw,28px)",
      padding: "var(--pad-card)",
      background: "var(--surface-card)",
      border: "var(--border-width) solid var(--border-card)",
      borderRadius: "var(--radius-card)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      width: 38,
      height: 38,
      borderRadius: "var(--radius-lg)",
      background: "var(--navy-900)",
      color: "var(--accent)",
      flex: "none"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 19
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: "1 1 320px"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: "var(--type-h3-size)",
      letterSpacing: "var(--type-h3-track)",
      color: "var(--navy-900)",
      margin: "0 0 6px"
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--type-small-size)",
      lineHeight: "var(--type-small-line)",
      color: "var(--text-muted)",
      margin: 0,
      maxWidth: "var(--measure-prose)",
      textWrap: "pretty"
    }
  }, children)));
}
Object.assign(__ds_scope, { NoticeCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/NoticeCard.jsx", error: String((e && e.message) || e) }); }

// components/core/ProgressBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ProgressBar({
  value = 0,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      flex: 1,
      height: 3,
      borderRadius: 2,
      background: "var(--surface-neutral)",
      overflow: "hidden",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      width: Math.max(0, Math.min(100, value)) + "%",
      height: "100%",
      background: "var(--accent-deep)",
      transition: "width .1s linear"
    }
  }));
}
Object.assign(__ds_scope, { ProgressBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/ProgressBar.jsx", error: String((e && e.message) || e) }); }

// components/core/TabSwitch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* The Lucy / Wilson switch. Active tab is a white card with a 2px accent underline
   in that product's colour; the group is a translucent well. */
function TabSwitch({
  tabs = [],
  value,
  onChange,
  tone = "dark",
  style,
  ...rest
}) {
  const active = value || tabs[0] && tabs[0].id;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 3,
      padding: 3,
      background: tone === "dark" ? "var(--overlay-on-dark)" : "var(--slate-150)",
      borderRadius: "var(--radius-tabgroup)",
      maxWidth: "100%",
      ...style
    }
  }, rest), tabs.map(t => {
    const on = t.id === active;
    return /*#__PURE__*/React.createElement("a", {
      key: t.id,
      href: "#",
      onClick: e => {
        e.preventDefault();
        if (onChange) onChange(t.id);
      },
      style: {
        fontSize: 13,
        fontWeight: 600,
        padding: "0 15px",
        minHeight: "var(--hit-min)",
        display: "inline-flex",
        alignItems: "center",
        borderRadius: "var(--radius-md)",
        textDecoration: "none",
        whiteSpace: "nowrap",
        transition: "all var(--dur-hover)",
        background: on ? "var(--white)" : "transparent",
        color: on ? "var(--navy-900)" : tone === "dark" ? "var(--text-on-dark-dim)" : "var(--text-muted)",
        borderBottom: "var(--border-tab-width) solid " + (on ? t.accent || "var(--accent)" : "transparent")
      }
    }, t.label);
  }));
}
Object.assign(__ds_scope, { TabSwitch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/TabSwitch.jsx", error: String((e && e.message) || e) }); }

// components/core/TextLink.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const linkVariants = {
  action: {
    fontSize: "var(--type-action-size)",
    fontWeight: 600,
    color: "var(--navy-900)",
    minHeight: "var(--hit-min)",
    gap: 7
  },
  nav: {
    fontSize: "var(--type-ui-size)",
    fontWeight: 500,
    color: "var(--text-muted)",
    gap: 6
  },
  footer: {
    fontSize: "var(--type-meta-size)",
    fontWeight: 400,
    color: "var(--text-muted)",
    gap: 6
  },
  contact: {
    fontFamily: "var(--font-display)",
    fontSize: "clamp(17px,2.6vw,20px)",
    fontWeight: 700,
    letterSpacing: "-.01em",
    color: "var(--navy-900)",
    gap: 9
  }
};
function TextLink({
  children,
  href = "#",
  variant = "action",
  icon,
  iconBefore,
  tone,
  style,
  ...rest
}) {
  const v = linkVariants[variant];
  return /*#__PURE__*/React.createElement("a", _extends({
    className: "wb-link",
    href: href,
    style: {
      display: "inline-flex",
      alignItems: "center",
      textDecoration: "none",
      ...v,
      color: tone || v.color,
      ...style
    }
  }, rest), iconBefore ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconBefore,
    size: variant === "contact" ? 18 : 15
  }) : null, children, icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 15
  }) : null);
}
Object.assign(__ds_scope, { TextLink });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/TextLink.jsx", error: String((e && e.message) || e) }); }

// components/content/ProductRow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* The product list is rows on hairlines, not cards. An unlaunched product keeps the
   same row but loses its colour: hollow dot, smaller name, muted copy. */
function ProductRow({
  name,
  description,
  meta,
  actionLabel,
  href = "#",
  accent = "var(--accent-lucy)",
  state = "live",
  style,
  ...rest
}) {
  const live = state === "live";
  return /*#__PURE__*/React.createElement("div", _extends({
    className: "wb-row",
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: "var(--gap-row)",
      alignItems: "baseline",
      padding: "var(--row-y) 0",
      borderBottom: "var(--border-width) solid var(--border-hairline)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      gap: 10,
      flex: "0 0 auto",
      minWidth: 170
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: "var(--radius-circle)",
      background: live ? accent : "transparent",
      border: live ? "none" : "1px solid var(--accent-magnolia)",
      transform: "translateY(-3px)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 800,
      fontSize: live ? "var(--type-product-size)" : 24,
      letterSpacing: "var(--type-product-track)",
      color: live ? "var(--navy-900)" : "var(--text-subtle)"
    }
  }, name)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: "1 1 300px"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: live ? "var(--type-copy-size)" : "var(--type-small-size)",
      lineHeight: "var(--type-copy-line)",
      color: live ? "var(--navy-900)" : "var(--text-subtle)",
      margin: "0 0 6px",
      maxWidth: "var(--measure-copy)",
      textWrap: "pretty"
    }
  }, description), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--type-label-size)",
      color: live ? "var(--text-subtle)" : "var(--text-muted)",
      margin: 0
    }
  }, meta)), /*#__PURE__*/React.createElement(__ds_scope.TextLink, {
    href: href,
    icon: "arrow-right",
    tone: live ? "var(--navy-900)" : "var(--text-subtle)",
    style: {
      flex: "0 0 auto"
    }
  }, actionLabel));
}
Object.assign(__ds_scope, { ProductRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/ProductRow.jsx", error: String((e && e.message) || e) }); }

// components/forms/FieldLabel.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Label + control, stacked. Every field in the system is built on this. */
function FieldLabel({
  label,
  children,
  hint,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", _extends({
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 7,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--type-label-size)",
      fontWeight: 600,
      color: "var(--navy-900)"
    }
  }, label), children, hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--type-fine-size)",
      lineHeight: 1.55,
      color: "var(--text-muted)"
    }
  }, hint) : null);
}
Object.assign(__ds_scope, { FieldLabel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/FieldLabel.jsx", error: String((e && e.message) || e) }); }

// components/forms/SelectField.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function SelectField({
  label,
  hint,
  options = [],
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.FieldLabel, {
    label: label,
    hint: hint
  }, /*#__PURE__*/React.createElement("select", _extends({
    className: "wb-field",
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "var(--type-small-size)",
      color: "var(--navy-900)",
      padding: "12px 13px",
      border: "var(--border-width) solid var(--border-field)",
      borderRadius: "var(--radius-md)",
      background: "var(--surface-field)",
      transition: "var(--transition-field)",
      ...style
    }
  }, rest), options.map(o => /*#__PURE__*/React.createElement("option", {
    key: o,
    value: o
  }, o))));
}
Object.assign(__ds_scope, { SelectField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/SelectField.jsx", error: String((e && e.message) || e) }); }

// components/forms/TextArea.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function TextArea({
  label,
  hint,
  rows = 4,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.FieldLabel, {
    label: label,
    hint: hint
  }, /*#__PURE__*/React.createElement("textarea", _extends({
    className: "wb-field",
    rows: rows,
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "var(--type-small-size)",
      color: "var(--navy-900)",
      padding: "12px 13px",
      border: "var(--border-width) solid var(--border-field)",
      borderRadius: "var(--radius-md)",
      background: "var(--surface-field)",
      resize: "vertical",
      transition: "var(--transition-field)",
      ...style
    }
  }, rest)));
}
Object.assign(__ds_scope, { TextArea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/TextArea.jsx", error: String((e && e.message) || e) }); }

// components/forms/TextField.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function TextField({
  label,
  hint,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.FieldLabel, {
    label: label,
    hint: hint
  }, /*#__PURE__*/React.createElement("input", _extends({
    className: "wb-field",
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "var(--type-small-size)",
      color: "var(--navy-900)",
      padding: "12px 13px",
      border: "var(--border-width) solid var(--border-field)",
      borderRadius: "var(--radius-md)",
      background: "var(--surface-field)",
      transition: "var(--transition-field)",
      ...style
    }
  }, rest)));
}
Object.assign(__ds_scope, { TextField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/TextField.jsx", error: String((e && e.message) || e) }); }

// components/voice/ChatBubble.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Agent speech is yellow; the person speaking is neutral. The square corner
   points at whoever is talking. */
function ChatBubble({
  children,
  who = "agent",
  style,
  ...rest
}) {
  const user = who === "user";
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      justifyContent: user ? "flex-end" : "flex-start"
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "84%",
      fontSize: "var(--type-bubble-size)",
      lineHeight: "var(--type-bubble-line)",
      padding: "9px 12px",
      borderRadius: user ? "12px 12px 3px 12px" : "12px 12px 12px 3px",
      background: user ? "var(--surface-neutral)" : "var(--accent)",
      color: "var(--navy-900)",
      fontWeight: user ? 400 : 500,
      border: user ? "var(--border-width) solid var(--border-panel)" : "none",
      ...style
    }
  }, children));
}
Object.assign(__ds_scope, { ChatBubble });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/voice/ChatBubble.jsx", error: String((e && e.message) || e) }); }

// components/voice/DoneToast.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Draft-complete banner: navy slab, yellow ring-pulse check, one chip action. */
function DoneToast({
  title,
  subtitle,
  action = "Review & submit",
  onAction,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      padding: "13px 15px",
      background: "var(--navy-900)",
      borderRadius: "var(--radius-toast)",
      boxShadow: "var(--shadow-toast)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      width: 26,
      height: 26,
      borderRadius: "var(--radius-circle)",
      background: "var(--accent)",
      color: "var(--navy-900)",
      fontSize: 15,
      fontWeight: 700,
      flex: "none",
      animation: "wb-ring 1.6s ease-out 2"
    }
  }, "\u2713"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 1,
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: 13,
      color: "var(--white)"
    }
  }, title), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--type-panel-meta-size)",
      color: "var(--text-on-dark-dim)"
    }
  }, subtitle)), action ? /*#__PURE__*/React.createElement("span", {
    onClick: onAction,
    style: {
      fontSize: "var(--type-panel-meta-size)",
      fontWeight: 700,
      color: "var(--navy-900)",
      background: "var(--accent)",
      padding: "7px 12px",
      borderRadius: "var(--radius-sm)",
      flex: "none",
      cursor: onAction ? "pointer" : "default"
    }
  }, action) : null);
}
Object.assign(__ds_scope, { DoneToast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/voice/DoneToast.jsx", error: String((e && e.message) || e) }); }

// components/voice/MicMeter.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Four bars in a 34px square. Yellow square + animated bars means listening. */
function MicMeter({
  listening = false,
  style,
  ...rest
}) {
  const bar = d => ({
    display: "block",
    width: 2.5,
    height: "100%",
    borderRadius: 2,
    background: listening ? "var(--navy-900)" : "rgba(20,27,46,.35)",
    animation: listening ? "wb-bar .9s ease-in-out " + d + "s infinite" : "none",
    transform: listening ? "none" : "scaleY(.4)"
  });
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      width: 34,
      height: 34,
      borderRadius: "var(--radius-lg)",
      flex: "none",
      background: listening ? "var(--accent)" : "var(--surface-neutral)",
      transition: "background var(--dur-fade)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 2.5,
      height: 15
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: bar(0)
  }), /*#__PURE__*/React.createElement("span", {
    style: bar(0.12)
  }), /*#__PURE__*/React.createElement("span", {
    style: bar(0.24)
  }), /*#__PURE__*/React.createElement("span", {
    style: bar(0.36)
  })));
}
Object.assign(__ds_scope, { MicMeter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/voice/MicMeter.jsx", error: String((e && e.message) || e) }); }

// ui_kits/voice_intake/FormPaper.jsx
try { (() => {
/* Right half: the real FDA form, scrolling in a slate well, with values written onto
   it in blue ink. Overlay positions are percentages of the paper, sizes are cqw so
   the ink scales with the paper. */
function FormPaper({
  label,
  fillCount,
  src,
  alt,
  overlays = [],
  scanning = false,
  shift = 0,
  done = false,
  doneTitle,
  doneSub
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      background: "var(--surface-well)",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: 0,
      left: 0,
      right: 0,
      zIndex: 3,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 10,
      padding: "9px 14px",
      background: "var(--surface-chrome)",
      borderBottom: "1px solid rgba(20,27,46,.10)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: "var(--type-panel-meta-size)",
      letterSpacing: ".02em",
      color: "var(--navy-900)",
      whiteSpace: "nowrap",
      overflow: "hidden",
      textOverflow: "ellipsis"
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--type-panel-micro-size)",
      color: "var(--text-muted)",
      whiteSpace: "nowrap",
      flex: "none"
    }
  }, fillCount)), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: "37px 26px 0 26px",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      transform: "translateY(" + shift + "%)",
      transition: "transform var(--dur-paper) var(--ease-paper)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      containerType: "inline-size",
      boxShadow: "var(--shadow-paper)"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: alt,
    loading: "lazy",
    decoding: "async",
    style: {
      width: "100%",
      height: "auto",
      display: "block"
    }
  }), overlays.map(o => /*#__PURE__*/React.createElement("div", {
    key: o.key,
    style: o.style
  }, o.text)), scanning ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      right: 0,
      top: 0,
      height: "26%",
      background: "linear-gradient(to bottom,rgba(244,180,0,0),rgba(244,180,0,.16),rgba(244,180,0,0))",
      animation: "wb-scan 2.4s linear infinite",
      pointerEvents: "none"
    }
  }) : null))), done ? /*#__PURE__*/React.createElement(__ds_scope.DoneToast, {
    title: doneTitle,
    subtitle: doneSub,
    style: {
      position: "absolute",
      left: 26,
      right: 26,
      bottom: 16,
      zIndex: 4
    }
  }) : null);
}
Object.assign(__ds_scope, { FormPaper });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/voice_intake/FormPaper.jsx", error: String((e && e.message) || e) }); }

// ui_kits/voice_intake/IntakePanel.jsx
try { (() => {
/* Left half of the intake surface: who is speaking, the transcript so far, and the
   transport. Panel fill is --surface-panel; everything is divided by hairlines. */
function IntakePanel({
  speaker,
  status,
  listening,
  messages = [],
  ctrlLabel,
  onToggle,
  progress = 0,
  clock
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      padding: "18px 18px 14px",
      background: "var(--surface-panel)",
      borderRight: "1px solid var(--border-panel)",
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      paddingBottom: 14,
      borderBottom: "1px solid var(--border-panel)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.MicMeter, {
    listening: listening
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 1,
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: "var(--type-panel-title-size)",
      color: "var(--navy-900)",
      whiteSpace: "nowrap"
    }
  }, speaker), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--type-panel-meta-size)",
      color: "var(--text-muted)"
    }
  }, status)), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--type-panel-tag-size)",
      fontWeight: 700,
      letterSpacing: ".14em",
      textTransform: "uppercase",
      color: "var(--text-muted)"
    }
  }, "demo")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: "1 1 0",
      minHeight: 0,
      display: "flex",
      flexDirection: "column",
      justifyContent: "flex-end",
      gap: 8,
      overflow: "hidden",
      padding: "14px 0 12px"
    }
  }, messages.map(m => /*#__PURE__*/React.createElement("div", {
    key: m.key,
    style: {
      opacity: m.opacity,
      transform: "translateY(" + m.rise + "px)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.ChatBubble, {
    who: m.who
  }, m.text)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 11,
      paddingTop: 12,
      borderTop: "1px solid var(--border-panel)"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: onToggle,
    style: {
      fontSize: "var(--type-panel-meta-size)",
      fontWeight: 600,
      textDecoration: "none",
      padding: "6px 12px",
      borderRadius: "var(--radius-sm)",
      background: "var(--navy-900)",
      color: "var(--white)",
      flex: "none"
    }
  }, ctrlLabel), /*#__PURE__*/React.createElement(__ds_scope.ProgressBar, {
    value: progress
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--type-panel-micro-size)",
      fontVariantNumeric: "tabular-nums",
      color: "var(--text-muted)"
    }
  }, clock)));
}
Object.assign(__ds_scope, { IntakePanel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/voice_intake/IntakePanel.jsx", error: String((e && e.message) || e) }); }

// ui_kits/voice_intake/VoiceIntake.jsx
try { (() => {
/* The Lucy / Wilson intake surface, timeline and transcript exactly as shipped.
   Lucy speaks plain English and files a 3500A; Wilson speaks clinically and files a 3500B. */
const INTAKE = {
  lucy: {
    speaker: "Lucy · voice intake",
    form: "3500A",
    paperLabel: "FDA MedWatch Form 3500A · page 1 of 9",
    img: "../../assets/medwatch-3500a-page1.png",
    total: 20200,
    shiftAt: 14000,
    shift: -32,
    fieldTotal: 9,
    narrAt: 15000,
    narrDur: 3000,
    narrative: "Patient (68-year-old female) began lisinopril 10 mg orally once daily on 12-Jul-2026 for hypertension. Approximately two days after the first dose she developed facial swelling (angioedema), throat tightness and a persistent dry cough. No emergency care was required. Product discontinued 16-Jul-2026; symptoms resolved within 48 hours — positive dechallenge. Reported by the patient's daughter through voice intake.",
    narrBox: {
      left: 7.6,
      top: 58.6,
      width: 84,
      size: 2.0
    },
    script: [{
      at: 500,
      who: "agent",
      text: "Hi, I'm Lucy. Tell me what happened — in your own words."
    }, {
      at: 1900,
      who: "user",
      text: "My mom started lisinopril last week, 10 milligrams. Two days later her face swelled up and she had this dry cough."
    }, {
      at: 4300,
      who: "agent",
      text: "Did she have any trouble breathing, or go to the ER?"
    }, {
      at: 5900,
      who: "user",
      text: "Her throat felt tight, but no ER. She stopped the pills and it settled down."
    }, {
      at: 7900,
      who: "agent",
      text: "Thank you. How old is she, and may I use her initials?"
    }, {
      at: 9300,
      who: "user",
      text: "She's 68. R.M."
    }, {
      at: 10500,
      who: "agent",
      text: "That's everything I need. Filling out your MedWatch 3500A now."
    }],
    fills: [{
      at: 11600,
      kind: "text",
      text: "R.M.",
      left: 7.4,
      top: 22.8,
      size: 2.1
    }, {
      at: 12100,
      kind: "text",
      text: "68",
      left: 49.4,
      top: 21.3,
      size: 2.1
    }, {
      at: 12450,
      kind: "check",
      left: 44.6,
      top: 22.4
    }, {
      at: 12850,
      kind: "check",
      left: 76.3,
      top: 24.1
    }, {
      at: 13300,
      kind: "check",
      left: 7.1,
      top: 43.1
    }, {
      at: 13750,
      kind: "check",
      left: 66.2,
      top: 46.6
    }, {
      at: 14200,
      kind: "text",
      text: "14-Jul-2026",
      left: 30.9,
      top: 52.6,
      size: 2.0
    }, {
      at: 14650,
      kind: "text",
      text: "25-Jul-2026",
      left: 76.2,
      top: 52.6,
      size: 2.0
    }]
  },
  wilson: {
    speaker: "Wilson · clinical intake",
    form: "3500B",
    paperLabel: "FDA MedWatch Form 3500B · Section A",
    img: "../../assets/medwatch-3500b-sectiona.png",
    total: 16200,
    shiftAt: 10300,
    shift: -20,
    fieldTotal: 4,
    narrAt: 11100,
    narrDur: 3100,
    narrative: "68-year-old female initiated lisinopril 10 mg PO daily on 12-Jul-2026 for hypertension. Onset of facial angioedema, throat tightness and non-productive cough approximately 48 hours after first dose. No airway compromise, no ED visit. Drug discontinued 16-Jul-2026 with complete resolution within 48 hours (positive dechallenge). Assessed as probably related — ACE-inhibitor angioedema. Reported by treating physician via voice intake.",
    narrBox: {
      left: 7.0,
      top: 41.9,
      width: 85,
      size: 2.0
    },
    script: [{
      at: 400,
      who: "agent",
      text: "Wilson here — go ahead whenever you're ready."
    }, {
      at: 1700,
      who: "user",
      text: "68-year-old female, started lisinopril 10 milligrams daily on the twelfth. Two days in, facial angioedema and a dry cough."
    }, {
      at: 4200,
      who: "agent",
      text: "Any airway compromise or ED visit?"
    }, {
      at: 5600,
      who: "user",
      text: "Throat tightness only, no ED. Drug stopped on the sixteenth, resolved in 48 hours — positive dechallenge."
    }, {
      at: 8200,
      who: "agent",
      text: "Understood. Coding it as a serious event and drafting the 3500B."
    }],
    fills: [{
      at: 9400,
      kind: "check",
      left: 6.3,
      top: 22.5
    }, {
      at: 9950,
      kind: "check",
      left: 48.6,
      top: 35.8
    }, {
      at: 10500,
      kind: "text",
      text: "14-Jul-2026",
      left: 14.3,
      top: 36.0,
      size: 2.0
    }]
  }
};
const clockOf = ms => "0:" + String(Math.max(0, Math.round(ms / 1000))).padStart(2, "0");
function VoiceIntake({
  variant = "lucy",
  autoplay = true,
  loop = false,
  speed = 1,
  imgSrc,
  height = 430
}) {
  const c = INTAKE[variant === "wilson" ? "wilson" : "lucy"];
  const [t, setT] = React.useState(0);
  const [running, setRunning] = React.useState(autoplay);
  const [ended, setEnded] = React.useState(false);
  React.useEffect(() => {
    setT(0);
    setEnded(false);
    setRunning(autoplay);
  }, [variant]);
  React.useEffect(() => {
    if (!running) return;
    let base = t,
      mark = performance.now();
    const id = setInterval(() => {
      const next = base + (performance.now() - mark) * speed;
      if (next >= c.total) {
        if (loop) {
          base = 0;
          mark = performance.now();
          setT(0);
        } else {
          setRunning(false);
          setT(c.total);
          setEnded(true);
        }
        return;
      }
      setT(next);
    }, 120);
    return () => clearInterval(id);
  }, [running, variant, speed, loop]);
  const shown = c.script.filter(m => t >= m.at);
  const last = shown[shown.length - 1];
  const listening = !!last && last.who === "user" && t - last.at < 1600;
  const filling = t >= c.fills[0].at - 300 && t < c.narrAt + c.narrDur;
  const done = t >= c.narrAt + c.narrDur + 200;
  const messages = shown.map((m, i) => {
    const p = Math.min(1, (t - m.at) / 260);
    return {
      key: i,
      who: m.who,
      text: m.text,
      opacity: p,
      rise: +((1 - p) * 7).toFixed(1)
    };
  });
  const overlays = [];
  const flash = age => (Math.max(0, 1 - age / 800) * 0.4).toFixed(2);
  c.fills.forEach((f, i) => {
    if (t < f.at) return;
    const age = t - f.at,
      pop = Math.min(1, age / 200);
    const common = {
      position: "absolute",
      left: f.left + "%",
      top: f.top + "%",
      fontFamily: "var(--font-form)",
      lineHeight: f.kind === "check" ? 1 : 1.2,
      color: "var(--ink-form)",
      opacity: pop,
      background: "rgba(244,180,0," + flash(age) + ")"
    };
    if (f.kind === "check") overlays.push({
      key: "c" + i,
      text: "✓",
      style: {
        ...common,
        fontSize: "2.3cqw",
        fontWeight: 700,
        transform: "scale(" + (0.7 + pop * 0.3).toFixed(2) + ")",
        transformOrigin: "left top"
      }
    });else overlays.push({
      key: "f" + i,
      text: f.text,
      style: {
        ...common,
        fontSize: f.size + "cqw",
        whiteSpace: "nowrap",
        padding: "0 .3cqw",
        borderRadius: ".3cqw"
      }
    });
  });
  if (t >= c.narrAt) {
    const p = Math.min(1, (t - c.narrAt) / c.narrDur);
    overlays.push({
      key: "narr",
      text: c.narrative.slice(0, Math.round(c.narrative.length * p)) + (p < 1 ? "▏" : ""),
      style: {
        position: "absolute",
        left: c.narrBox.left + "%",
        top: c.narrBox.top + "%",
        width: c.narrBox.width + "%",
        fontFamily: "var(--font-form)",
        fontSize: c.narrBox.size + "cqw",
        lineHeight: 1.5,
        color: "var(--ink-form)",
        textAlign: "left"
      }
    });
  }
  let status = "Tap play to watch";
  if (running) status = listening ? "Listening…" : filling ? "Filling FDA Form " + c.form + "…" : "Thinking…";else if (done) status = "Draft ready · 0 fields missing";else if (t > 0) status = "Paused";
  const toggle = e => {
    e.preventDefault();
    if (ended) {
      setT(0);
      setEnded(false);
      setRunning(true);
    } else setRunning(r => !r);
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "wb-intake",
    style: {
      display: "grid",
      gridTemplateColumns: "0.82fr 1fr",
      border: "1px solid var(--border-panel)",
      borderRadius: "var(--radius-panel)",
      overflow: "hidden",
      height: height,
      background: "var(--surface-card)",
      boxShadow: "var(--shadow-panel)",
      fontFamily: "var(--font-body)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.IntakePanel, {
    speaker: c.speaker,
    status: status,
    listening: listening,
    messages: messages,
    ctrlLabel: ended ? "Replay" : running ? "Pause" : "Play",
    onToggle: toggle,
    progress: t / c.total * 100,
    clock: clockOf(t) + " / " + clockOf(c.total)
  }), /*#__PURE__*/React.createElement(__ds_scope.FormPaper, {
    label: c.paperLabel,
    src: imgSrc || c.img,
    alt: "FDA MedWatch Form " + c.form,
    fillCount: overlays.length === 0 ? "waiting for the conversation" : done ? c.fieldTotal + " of " + c.fieldTotal + " required fields" : overlays.length + " fields written",
    overlays: overlays,
    scanning: filling,
    shift: t >= c.shiftAt ? c.shift : 0,
    done: done,
    doneTitle: "Draft " + c.form + " complete — " + c.fieldTotal + " fields, 0 missing",
    doneSub: "Built from a one-minute conversation \xB7 ready for your review"
  }));
}
Object.assign(__ds_scope, { VoiceIntake });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/voice_intake/VoiceIntake.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/AboutSection.jsx
try { (() => {
function AboutSection({
  showFounders = true,
  photoBase = "../../assets/"
}) {
  return /*#__PURE__*/React.createElement("div", {
    id: "about",
    style: {
      background: "var(--surface-dark)",
      color: "var(--white)",
      padding: "var(--pad-section-y) var(--pad-gutter-x)",
      scrollMarginTop: "var(--scroll-offset)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--measure-page)",
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, {
    tone: "onDark",
    style: {
      marginBottom: 18
    }
  }, "About"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit,minmax(300px,1fr))",
      gap: "var(--gap-grid-wide)",
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.SectionHeading, {
    tone: "onDark",
    maxWidth: "17em"
  }, "A mission-driven team dedicated to improving people's lives.\xA0"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--type-body-size)",
      lineHeight: "var(--type-body-line)",
      color: "var(--text-on-dark-prose)",
      margin: 0,
      textWrap: "pretty"
    }
  }, "Warbler Safety is an independent company. We're not the FDA, and we're not owned by a drug manufacturer. That independence is the point: the only outcome we optimize for is that more real adverse events get reported, accurately, by the people who experienced them."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--type-body-size)",
      lineHeight: "var(--type-body-line)",
      color: "var(--text-on-dark-prose)",
      margin: 0,
      textWrap: "pretty"
    }
  }, "Lucy and Wilson are free, and they'll stay free. Magnolia, our enterprise product, is held to the same standard."))), showFounders ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit,minmax(258px,1fr))",
      gap: "clamp(16px,2.5vw,24px)",
      marginTop: "clamp(36px,5vw,54px)",
      paddingTop: "clamp(32px,4vw,44px)",
      borderTop: "1px solid var(--border-on-dark)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.PersonCard, {
    photo: photoBase + "founder-noah-delay.png",
    name: "Noah DeLay",
    role: "Co-founder & CEO"
  }, "Came to the problem from two directions: oncology research at City of Hope, where he saw how routinely adverse events went unreported, and the San Francisco Department of Public Health, where he learned how to advocate for patients.\xA0"), /*#__PURE__*/React.createElement(__ds_scope.PersonCard, {
    photo: photoBase + "founder-stephen-diteljan.png",
    name: "Stephen Diteljan",
    role: "Co-founder & CTO"
  }, "Engineering leader in AI and data infrastructure. Six years at Capital One as a senior engineering manager: data lineage automation across Spark and Databricks, and the enterprise blockchain group. Deeply versed in building software in a regulated context.\xA0")) : null));
}
Object.assign(__ds_scope, { AboutSection });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/AboutSection.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/AfterCallSection.jsx
try { (() => {
function AfterCallSection() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface-warm)",
      padding: "var(--pad-section-y-tight) var(--pad-gutter-x)",
      borderBottom: "1px solid var(--cream-line-2)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--measure-page)",
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, {
    style: {
      marginBottom: 12
    }
  }, "After the call"), /*#__PURE__*/React.createElement(__ds_scope.SectionHeading, {
    maxWidth: "17em",
    style: {
      marginBottom: "var(--space-heading-after)"
    }
  }, "You read it before anyone else. Then it goes where it needs to."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit,minmax(232px,1fr))",
      gap: "var(--gap-grid)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.NumberedStep, {
    number: "01",
    title: "You review every field"
  }, "Nothing is filed until you've read the completed form and confirmed it. Correct anything Warbler misheard, add what it missed."), /*#__PURE__*/React.createElement(__ds_scope.NumberedStep, {
    number: "02",
    title: "It's submitted to the FDA"
  }, "On your confirmation, the finished MedWatch report is filed with the FDA \u2014 the same report a pharmacist or hospital would send."), /*#__PURE__*/React.createElement(__ds_scope.NumberedStep, {
    number: "03",
    title: "Your physician gets a copy"
  }, "A copy is emailed to the doctor you name, so the person managing your care knows what happened without you having to explain it twice.")), /*#__PURE__*/React.createElement(__ds_scope.NoticeCard, {
    icon: "shield-off",
    title: "We keep nothing.",
    style: {
      marginTop: "var(--space-block-after)"
    }
  }, "Warbler doesn't store your recording, your completed form, or any health information you put through this service. Once your report is filed and the copy is sent, nothing of yours remains on our servers.")));
}
Object.assign(__ds_scope, { AfterCallSection });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/AfterCallSection.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/ContactSection.jsx
try { (() => {
function ContactSection() {
  const [sent, setSent] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    id: "contact",
    style: {
      background: "var(--surface-warm)",
      padding: "var(--pad-section-y) var(--pad-gutter-x)",
      scrollMarginTop: "var(--scroll-offset)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--measure-page)",
      margin: "0 auto",
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit,minmax(290px,1fr))",
      gap: "var(--gap-columns)",
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, {
    style: {
      marginBottom: 16
    }
  }, "Contact"), /*#__PURE__*/React.createElement(__ds_scope.SectionHeading, {
    maxWidth: "11em",
    style: {
      marginBottom: 18
    }
  }, "Get in touch."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--type-body-size)",
      lineHeight: 1.6,
      color: "var(--text-muted)",
      margin: "0 0 26px",
      maxWidth: "26em",
      textWrap: "pretty"
    }
  }, "Whether you want early access, want to bring Warbler into a health system, or just want to know how it works \u2014 write to us."), /*#__PURE__*/React.createElement(__ds_scope.TextLink, {
    variant: "contact",
    iconBefore: "mail",
    href: "mailto:hello@warblersafety.com"
  }, "hello@warblersafety.com"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--type-meta-size)",
      lineHeight: 1.6,
      color: "var(--text-muted)",
      margin: "22px 0 0",
      maxWidth: "24em"
    }
  }, "If you're reporting an adverse event that needs urgent medical attention, contact your doctor or emergency services first.")), /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      setSent(true);
    },
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14,
      background: "var(--surface-card)",
      border: "1px solid var(--border-card)",
      borderRadius: "var(--radius-panel)",
      padding: "var(--pad-form)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.TextField, {
    label: "Name",
    name: "name",
    placeholder: "Your name"
  }), /*#__PURE__*/React.createElement(__ds_scope.TextField, {
    label: "Email",
    type: "email",
    name: "email",
    placeholder: "you@example.com"
  }), /*#__PURE__*/React.createElement(__ds_scope.SelectField, {
    label: "I am a",
    name: "role",
    options: ["Patient or caregiver", "Clinician", "Pharma or biotech", "Something else"]
  }), /*#__PURE__*/React.createElement(__ds_scope.TextArea, {
    label: "Message",
    name: "message",
    placeholder: "How can we help?"
  }), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    size: "form",
    type: "submit",
    block: true,
    style: {
      marginTop: 2
    }
  }, sent ? "Thanks — we will be in touch" : "Send message"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--type-fine-size)",
      lineHeight: 1.55,
      color: "var(--text-muted)",
      margin: 0,
      textWrap: "pretty"
    }
  }, "Please don't include patient identifiers or clinical details in this form."))));
}
Object.assign(__ds_scope, { ContactSection });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/ContactSection.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/DemoSection.jsx
try { (() => {
/* The one navy section above the fold. Switching audience remounts the intake so the
   timeline restarts from zero. */
function DemoSection() {
  const [who, setWho] = React.useState("lucy");
  return /*#__PURE__*/React.createElement("div", {
    id: "demo",
    style: {
      background: "var(--surface-dark)",
      padding: "clamp(40px,6vw,64px) clamp(16px,5vw,56px) clamp(40px,6vw,60px)",
      scrollMarginTop: "var(--scroll-offset)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      alignItems: "flex-end",
      justifyContent: "space-between",
      gap: 20,
      maxWidth: "var(--measure-demo)",
      margin: "0 auto 24px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: "1 1 300px"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, {
    tone: "onDark",
    style: {
      marginBottom: 8
    }
  }, "Live demo"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 600,
      fontSize: "clamp(18px,3vw,21px)",
      lineHeight: 1.35,
      letterSpacing: "-.01em",
      color: "var(--white)",
      margin: 0,
      maxWidth: "22em"
    }
  }, "One minute of conversation.", /*#__PURE__*/React.createElement("br", null), "A submission-ready FDA form.")), /*#__PURE__*/React.createElement(__ds_scope.TabSwitch, {
    value: who,
    onChange: setWho,
    tabs: [{
      id: "lucy",
      label: "Lucy for patients · 3500A",
      accent: "var(--accent-lucy)"
    }, {
      id: "wilson",
      label: "Wilson for clinicians\u00a0· 3500B",
      accent: "var(--accent-wilson)"
    }]
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--measure-demo)",
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.VoiceIntake, {
    key: who,
    variant: who
  })));
}
Object.assign(__ds_scope, { DemoSection });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/DemoSection.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/HeroSection.jsx
try { (() => {
/* Centred, no image, no button — the demo below it is the hero image. */
function HeroSection() {
  return /*#__PURE__*/React.createElement("div", {
    id: "top",
    style: {
      padding: "clamp(48px,8vw,72px) var(--pad-gutter-x) clamp(36px,5vw,48px)",
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, {
    style: {
      marginBottom: 20
    }
  }, "Voice-first pharmacovigilance"), /*#__PURE__*/React.createElement(__ds_scope.SectionHeading, {
    level: "h1",
    center: true,
    style: {
      marginBottom: 20
    }
  }, "Safer medications for everyone."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--type-lead-size)",
      lineHeight: "var(--type-lead-line)",
      color: "var(--text-muted)",
      margin: "0 auto 12px",
      maxWidth: "var(--measure-lead)",
      textWrap: "pretty"
    }
  }, "Tell us what happened in your own words. We'll turn it into a report the FDA can use."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--type-lead-size)",
      lineHeight: "var(--type-lead-line)",
      fontWeight: 600,
      color: "var(--navy-900)",
      margin: "0 auto",
      maxWidth: "var(--measure-lead)"
    }
  }, "Free for patients and clinicians."));
}
Object.assign(__ds_scope, { HeroSection });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/HeroSection.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/MissionSection.jsx
try { (() => {
/* Two columns of evidence, then the claim, then the sources. The order is the argument. */
function MissionSection() {
  return /*#__PURE__*/React.createElement("div", {
    id: "mission",
    style: {
      padding: "clamp(20px,3vw,28px) var(--pad-gutter-x) clamp(64px,8vw,92px)",
      maxWidth: "var(--measure-page)",
      margin: "0 auto",
      scrollMarginTop: "var(--scroll-offset)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, {
    style: {
      marginBottom: 18
    }
  }, "Our mission"), /*#__PURE__*/React.createElement(__ds_scope.SectionHeading, {
    level: "lead",
    style: {
      marginBottom: "clamp(28px,4vw,40px)"
    }
  }, "Most adverse drug reactions are never reported."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit,minmax(290px,1fr))",
      gap: "var(--gap-grid-wide)",
      maxWidth: 860
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--type-prose-size)",
      lineHeight: "var(--type-prose-line)",
      color: "var(--text-prose)",
      margin: 0,
      textWrap: "pretty"
    }
  }, "Every adverse drug event is a signal about how a medicine behaves outside a clinical trial. CDC surveillance puts medication-related harm at roughly 6 emergency department visits per 1,000 people a year, and about four in ten of those visits end in a hospital admission."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--type-prose-size)",
      lineHeight: "var(--type-prose-line)",
      color: "var(--text-prose)",
      margin: 0,
      textWrap: "pretty"
    }
  }, "Most of those signals never reach a regulator. A systematic review found a median of 94% of adverse drug reactions go unreported \u2014 though estimates ranged widely across the studies it pooled, and no one knows the true figure. What's consistent is the direction, and that the effort the forms demand is part of why.")), /*#__PURE__*/React.createElement(__ds_scope.Pullquote, {
    style: {
      margin: "clamp(32px,5vw,48px) 0 0"
    }
  }, "We help patients and clinicians submit structured adverse event reports more efficiently and accurately.\xA0"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--type-fine-size)",
      lineHeight: "var(--type-fine-line)",
      color: "var(--text-muted)",
      margin: "clamp(24px,3.5vw,32px) 0 0",
      maxWidth: "var(--measure-prose)",
      textWrap: "pretty"
    }
  }, "Sources: Budnitz et al., ", /*#__PURE__*/React.createElement("em", null, "JAMA"), " (2021) \u2014 CDC NEISS-CADES surveillance, 2017\u20132019: an estimated 6.1 ED visits per 1,000 population annually (95% CI 4.8\u20137.5), 38.6% resulting in hospitalization. Hazell & Shakir, ", /*#__PURE__*/React.createElement("em", null, "Drug Safety"), " (2006): median under-reporting rate of 94%, interquartile range 82\u201398%."));
}
Object.assign(__ds_scope, { MissionSection });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/MissionSection.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/ProductsSection.jsx
try { (() => {
function ProductsSection({
  launchLine = "Launching this month",
  showMagnolia = true
}) {
  return /*#__PURE__*/React.createElement("div", {
    id: "products",
    style: {
      padding: "clamp(60px,8vw,84px) var(--pad-gutter-x) clamp(56px,7vw,78px)",
      maxWidth: "var(--measure-page)",
      margin: "0 auto",
      scrollMarginTop: "var(--scroll-offset)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, {
    tone: "neutral",
    style: {
      marginBottom: 6
    }
  }, "Products for patients, clinicians, and enterprises"), /*#__PURE__*/React.createElement(__ds_scope.ProductRow, {
    name: "Lucy",
    accent: "var(--accent-lucy)",
    href: "#contact",
    actionLabel: "Report an event",
    meta: "Free · " + launchLine,
    description: "Patients and caregivers report a side effect in their own words. Lucy asks the rest and files the MedWatch 3500A."
  }), /*#__PURE__*/React.createElement(__ds_scope.ProductRow, {
    name: "Wilson",
    accent: "var(--accent-wilson)",
    href: "#contact",
    actionLabel: "Request access",
    meta: "Free · " + launchLine,
    description: "The same voice-to-FDA form as Lucy, but optimized for a clinical idiom and filed as a MedWatch 3500B."
  }), showMagnolia ? /*#__PURE__*/React.createElement(__ds_scope.ProductRow, {
    name: "Magnolia",
    state: "upcoming",
    href: "#contact",
    actionLabel: "Join the waitlist",
    meta: "Enterprise \xB7 Later this year",
    description: "AI-native adverse event processing for pharma companies: intake, triage, coding and case narratives on the engine behind Lucy and Wilson."
  }) : null);
}
Object.assign(__ds_scope, { ProductsSection });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/ProductsSection.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/SiteFooter.jsx
try { (() => {
const footerCols = [{
  title: "Products",
  links: [["Lucy", "#products"], ["Wilson", "#products"], ["Magnolia", "#products"]]
}, {
  title: "Company",
  links: [["Mission", "#mission"], ["About", "#about"], ["Contact", "#contact"]]
}, {
  title: "Legal",
  links: [["Privacy", "#"], ["Terms", "#"]]
}];
function SiteFooter({
  markSrc = "../../assets/logo-warbler-mark.png"
}) {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: "var(--surface-page)",
      padding: "clamp(40px,6vw,56px) var(--pad-gutter-x) clamp(28px,4vw,36px)",
      borderTop: "1px solid var(--border-hairline)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--measure-page)",
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 28,
      justifyContent: "space-between",
      alignItems: "flex-start"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: "1 1 260px"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Logo, {
    markSrc: markSrc,
    height: 26,
    wordSize: 16,
    accent: "var(--gold-700)",
    style: {
      marginBottom: 10
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--type-meta-size)",
      lineHeight: 1.55,
      color: "var(--text-subtle)",
      margin: 0,
      maxWidth: "22em"
    }
  }, "Adverse event reporting by voice. Free for patients and clinicians.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: "clamp(24px,5vw,56px)",
      flex: "0 1 auto"
    }
  }, footerCols.map(col => /*#__PURE__*/React.createElement("div", {
    key: col.title,
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 9
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      letterSpacing: "var(--type-kicker-track)",
      textTransform: "uppercase",
      color: "var(--text-subtle)"
    }
  }, col.title), col.links.map(([label, href]) => /*#__PURE__*/React.createElement(__ds_scope.TextLink, {
    key: label,
    variant: "footer",
    href: href
  }, label)))))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "clamp(32px,4vw,44px)",
      paddingTop: 22,
      borderTop: "1px solid var(--border-hairline)",
      display: "flex",
      flexWrap: "wrap",
      gap: 16,
      justifyContent: "space-between",
      alignItems: "flex-start"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--type-fine-size)",
      lineHeight: 1.6,
      color: "var(--text-muted)",
      margin: 0,
      maxWidth: "60em",
      textWrap: "pretty"
    }
  }, "Warbler Safety is an independent service and is not affiliated with, endorsed by, or acting on behalf of the U.S. Food and Drug Administration. MedWatch and FDA Forms 3500A and 3500B are products of the FDA, and reports may also be filed directly with the FDA at no cost. Warbler helps you complete and submit those reports more accurately and more quickly. Warbler does not provide medical advice, diagnosis, or treatment."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--type-fine-size)",
      color: "var(--text-subtle)",
      margin: 0,
      whiteSpace: "nowrap"
    }
  }, "\xA9 2026 Warbler Safety"))));
}
Object.assign(__ds_scope, { SiteFooter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/SiteFooter.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/SiteHeader.jsx
try { (() => {
/* Sticky, hairline-bottomed, translucent white with an 8px blur. Nav links collapse
   below 760px and only the CTA survives. */
function SiteHeader({
  markSrc = "../../assets/logo-warbler-mark.png",
  onNavigate
}) {
  const go = id => e => {
    if (onNavigate) {
      e.preventDefault();
      onNavigate(id);
    }
  };
  return /*#__PURE__*/React.createElement("header", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 16,
      padding: "var(--pad-header-y) var(--pad-gutter-x)",
      borderBottom: "1px solid var(--border-hairline)",
      position: "sticky",
      top: 0,
      background: "var(--header-scrim)",
      backdropFilter: "var(--blur-header)",
      zIndex: 20
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Logo, {
    markSrc: markSrc,
    href: "#top",
    onClick: go("top")
  }), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--gap-nav)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "wb-navlinks",
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--gap-nav)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.TextLink, {
    variant: "nav",
    href: "#demo",
    onClick: go("demo")
  }, "Demo"), /*#__PURE__*/React.createElement(__ds_scope.TextLink, {
    variant: "nav",
    href: "#products",
    onClick: go("products")
  }, "Products"), /*#__PURE__*/React.createElement(__ds_scope.TextLink, {
    variant: "nav",
    href: "#mission",
    onClick: go("mission")
  }, "Mission"), /*#__PURE__*/React.createElement(__ds_scope.TextLink, {
    variant: "nav",
    href: "#about",
    onClick: go("about")
  }, "About")), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    href: "#contact",
    onClick: go("contact")
  }, "Request access")));
}
Object.assign(__ds_scope, { SiteHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/SiteHeader.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/WarblerSite.jsx
try { (() => {
/* warblersafety.com, top to bottom. White page, two navy sections, two cream sections. */
function WarblerSite({
  launchLine = "Launching this month",
  showMagnolia = true,
  showFounders = true,
  assetBase = "../../assets/"
}) {
  const scrollTo = id => {
    const el = document.getElementById(id);
    if (el) window.scrollTo({
      top: id === "top" ? 0 : el.offsetTop - 74,
      behavior: "smooth"
    });
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface-page)",
      color: "var(--navy-900)",
      overflowX: "hidden"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.SiteHeader, {
    markSrc: assetBase + "logo-warbler-mark.png",
    onNavigate: scrollTo
  }), /*#__PURE__*/React.createElement(__ds_scope.HeroSection, null), /*#__PURE__*/React.createElement(__ds_scope.DemoSection, null), /*#__PURE__*/React.createElement(__ds_scope.AfterCallSection, null), /*#__PURE__*/React.createElement(__ds_scope.ProductsSection, {
    launchLine: launchLine,
    showMagnolia: showMagnolia
  }), /*#__PURE__*/React.createElement(__ds_scope.MissionSection, null), /*#__PURE__*/React.createElement(__ds_scope.AboutSection, {
    showFounders: showFounders,
    photoBase: assetBase
  }), /*#__PURE__*/React.createElement(__ds_scope.ContactSection, null), /*#__PURE__*/React.createElement(__ds_scope.SiteFooter, {
    markSrc: assetBase + "logo-warbler-mark.png"
  }));
}
Object.assign(__ds_scope, { WarblerSite });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/WarblerSite.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Eyebrow = __ds_scope.Eyebrow;

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.Pullquote = __ds_scope.Pullquote;

__ds_ns.SectionHeading = __ds_scope.SectionHeading;

__ds_ns.NoticeCard = __ds_scope.NoticeCard;

__ds_ns.NumberedStep = __ds_scope.NumberedStep;

__ds_ns.PersonCard = __ds_scope.PersonCard;

__ds_ns.ProductRow = __ds_scope.ProductRow;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.ProgressBar = __ds_scope.ProgressBar;

__ds_ns.TabSwitch = __ds_scope.TabSwitch;

__ds_ns.TextLink = __ds_scope.TextLink;

__ds_ns.FieldLabel = __ds_scope.FieldLabel;

__ds_ns.SelectField = __ds_scope.SelectField;

__ds_ns.TextArea = __ds_scope.TextArea;

__ds_ns.TextField = __ds_scope.TextField;

__ds_ns.ChatBubble = __ds_scope.ChatBubble;

__ds_ns.DoneToast = __ds_scope.DoneToast;

__ds_ns.MicMeter = __ds_scope.MicMeter;

__ds_ns.FormPaper = __ds_scope.FormPaper;

__ds_ns.IntakePanel = __ds_scope.IntakePanel;

__ds_ns.VoiceIntake = __ds_scope.VoiceIntake;

__ds_ns.AboutSection = __ds_scope.AboutSection;

__ds_ns.AfterCallSection = __ds_scope.AfterCallSection;

__ds_ns.ContactSection = __ds_scope.ContactSection;

__ds_ns.DemoSection = __ds_scope.DemoSection;

__ds_ns.HeroSection = __ds_scope.HeroSection;

__ds_ns.MissionSection = __ds_scope.MissionSection;

__ds_ns.ProductsSection = __ds_scope.ProductsSection;

__ds_ns.SiteFooter = __ds_scope.SiteFooter;

__ds_ns.SiteHeader = __ds_scope.SiteHeader;

__ds_ns.WarblerSite = __ds_scope.WarblerSite;

})();
