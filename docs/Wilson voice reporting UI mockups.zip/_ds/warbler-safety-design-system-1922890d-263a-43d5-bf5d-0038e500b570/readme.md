# Warbler Safety — Design System

Warbler Safety is a patient-centered, AI-native drug safety company. Its software turns a
one-minute spoken conversation into a completed FDA MedWatch adverse event report — free for
patients and clinicians — and will extend into full ICSR and adverse event case processing
services for U.S. pharma. The mission, in the company's own words: reduce mortality and
hospitalizations from harmful reactions to medications.

Everything in this design system was derived from the shipped product, not invented. Values are
literal: if the site says 15.5px, this system says 15.5px.

## Products represented

| Product | Audience | What it does | Status (per the site) |
| --- | --- | --- | --- |
| **Lucy** | Patients & caregivers | Voice intake in plain language → files FDA MedWatch **3500A** | Free · launching |
| **Wilson** | Clinicians | Same engine, clinical idiom → files FDA MedWatch **3500B** | Free · launching |
| **Magnolia** | Pharma / biotech | AE processing: intake, triage, coding, case narratives | Enterprise · later this year |
| **warblersafety.com** | Everyone | One-page marketing site with the live intake demo embedded | Live |

Magnolia has no UI anywhere in the sources. It appears only as a muted, colourless row in the
product list — that restraint is the design, and this system reproduces it rather than inventing
screens for it.

## Sources used

- **GitHub — [github.com/noahdelay-tech/Warblersafetyweb](https://github.com/noahdelay-tech/Warblersafetyweb)** (branch `main`).
  The repo is a GitHub Pages deployment: `CNAME` (`www.warblersafety.com`) plus a single 3.2 MB
  `index.html`, which is a self-contained bundle — a base64 asset manifest and the page markup
  stored as a JSON string. It was unpacked into `_source/` in this project:
  - `_source/site-source.html` — the real page template (the marketing site).
  - `_source/FormFillDemo.dc.html` — the nested live-demo component (Lucy/Wilson intake).
  - Fonts, images and the bundled Lucide 1.27.0 build, all now living in `assets/`.
  Worth exploring further if you want more fidelity than this system captures — and it is the
  place to look when the site changes.
- **Live site** — `https://www.warblersafety.com/` (renders only with JavaScript; the HTML is the bundle).
- **Upload** — `uploads/warblerlogo.png`, the warbler mark on a white field. The site ships the
  same mark with transparency; that transparent version is what `assets/` uses.

No Figma file, brand book, deck, or app codebase was provided. Anything a design system would
normally take from those (dark mode, data viz, email templates, empty/error states, mobile app
chrome) is genuinely absent — see **Gaps** at the end.

---

## CONTENT FUNDAMENTALS

**The voice is a careful clinician who refuses to oversell.** Every claim is either something the
user does, something the company does, or a cited number. Nothing is aspirational.

**Person.** "You" for the reader, "we" for the company — both used freely, in the same sentence
when needed: *"Tell us what happened in your own words. We'll turn it into a report the FDA can
use."* The company says "we" even when disclaiming: *"We keep nothing."* Third person only for
the legal footer (*"Warbler Safety is an independent service…"*) and founder bios.

**Casing.** Sentence case everywhere — headings, buttons, labels, nav. The single exception is the
eyebrow label above each section, which is uppercase and tracked to .19em ("VOICE-FIRST
PHARMACOVIGILANCE", "AFTER THE CALL", "OUR MISSION"). Product names are proper nouns: Lucy,
Wilson, Magnolia. Regulatory names are exact: FDA MedWatch, Form 3500A, Form 3500B, ICSR.

**Punctuation.** Headings end in a period, because they are statements: *"Safer medications for
everyone." "Get in touch." "Most adverse drug reactions are never reported."* Em dashes carry the
qualifying clause; the middle dot separates metadata (`Free · Launching this month`,
`0:12 / 0:20`, `Enterprise · Later this year`). No exclamation marks anywhere.

**Length.** One idea per paragraph, two or three sentences. Headings are 5–11 words and wrap into
2–3 lines by design (measures are capped at 11–17em). Product descriptions are exactly one
sentence naming the audience and the artefact produced.

**Hedging is a feature.** The mission section states 94% under-reporting and then immediately
undercuts its own number: *"though estimates ranged widely across the studies it pooled, and no one
knows the true figure. What's consistent is the direction."* Sources are named inline with journal
and year. When writing new copy: if you cannot cite it, soften it or cut it.

**Product copy is literal about state.** The intake surface says "Listening…", "Thinking…",
"Filling FDA Form 3500A…", "Draft ready · 0 fields missing", "9 of 9 required fields". Never
"Processing", never "Success!". The completion banner counts fields and hands control back:
*"Draft 3500A complete — 9 fields, 0 missing"* / *"ready for your review"*. Nothing claims
submission has happened, because the person confirms first.

**Safety copy always appears next to the thing it constrains.** The contact form ends with
*"Please don't include patient identifiers or clinical details in this form."* The contact section
ends with *"If you're reporting an adverse event that needs urgent medical attention, contact your
doctor or emergency services first."*

**Agent dialogue.** Lucy asks one short question at a time in lay terms ("Did she have any trouble
breathing, or go to the ER?"). Wilson is terse and clinical ("Any airway compromise or ED visit?").
Both open by inviting the person to speak first.

**Never used:** emoji, exclamation marks, ALL-CAPS words for emphasis, "revolutionary" /
"seamless" / "cutting-edge", growth-marketing urgency, testimonials, logo walls, star ratings, or
percentages without a citation.

---

## VISUAL FOUNDATIONS

**The idea.** A federal form is intimidating; a conversation is not. So the brand puts warm,
plain-spoken editorial typography around a cool, precise document. Nothing decorative appears
anywhere — no illustration, no gradient background, no pattern, no texture, no photography except
two founder headshots. The only "image" the product shows is the real FDA paper filling itself in.

**Colour.** Three values do the work: navy ink `#141B2E`, Warbler yellow `#F4B400`, deep gold
`#B07C00`. Yellow is *never* text on white (it fails contrast) — for text it becomes `#8A6100`
(`--gold-700`); for links on hover it becomes `#B07C00`. Yellow is reserved for: eyebrows on navy,
the agent's speech bubbles, a single glyph in a navy square, the pullquote rule, the active-tab
underline, founder role lines, and the ink-flash as a form field is written. Teal `#0F8A86` exists
only to mark Wilson (clinicians) against Lucy's yellow. There are exactly two background families:
warm creams (`#F7F6F2`, `#FBFBF9`, page backdrop `#e7e5df`) for the marketing story, and cool
slates (`#FBFCFD`, `#EEF1F5`, `#DFE2E8`, `#F4F5F7`) inside the product UI. Do not mix them in one
panel. Two navy sections per page maximum, never adjacent.

**Type.** Schibsted Grotesk (500–800) for anything that carries the voice — headings, wordmark,
product names, card titles, panel titles. Hanken Grotesk (400–700) for everything read at length —
body, labels, fields, legal, product UI. Display type is always negatively tracked and tight:
h1 800 / clamp(34→58px) / 1.03 / -.03em; section h2 700 / clamp(25→34px) / 1.18 / -.022em; the one
lead h2 per page 700 / clamp(27→40px) / -.028em. Body sits at 15–16.5px with generous leading
(1.55–1.62) in muted navy, not black. A third face, Helvetica, appears only as pen-ink written onto
the MedWatch scan (`--font-form`, colour `#14235A`).

**Layout.** One 1000px content column (`--measure-page`); the live demo is 960px. Gutters and
section padding are `clamp()` pairs, not breakpoint tables — `clamp(60px,8vw,88px)` vertical,
`clamp(20px,5vw,56px)` horizontal. Multi-column areas are `repeat(auto-fit,minmax(232–300px,1fr))`
grids with `clamp()` gaps, so they reflow without media queries. Only two real media queries exist
in the source: hide nav links below 760px, and stack the demo's two panes. The header is the only
fixed element: sticky at top, `rgba(255,255,255,.94)` with `backdrop-filter: blur(8px)`, hairline
bottom, z-index 20 — and every anchor carries `scroll-margin-top: 74px` to clear it. Measures are
capped aggressively: headings 11–17em, lead copy 31em, product descriptions 34em, fine print 52em.
`text-wrap: balance` on headings, `pretty` on paragraphs.

**Borders over shadows.** Structure comes from 1px hairlines, and there are four of them for four
jobs: page `#F0F1F4`, cream card `#E9E7DF`, input `#E2E0D8`, product panel `#E5E8EE`. The product
list is rows on hairlines rather than cards. Cards on cream carry **no shadow at all**.

**Shadow, when it appears, is navy-tinted and heavily negative-spread** — a lift off the page, never
a glow: panel `0 24px 60px -34px rgba(20,27,46,.45)`, paper `0 18px 44px -22px rgba(20,27,46,.55)`,
toast `0 18px 40px -18px rgba(20,27,46,.7)`. Focus is a 3px navy ring at 8% opacity plus a navy
border — `0 0 0 3px rgba(20,27,46,.08)`.

**Radii climb with size:** 8px button, 9px field / tab / textarea, 10px icon square, 11px tab well,
13px toast, 14px notice card, 16px panel and demo frame, 50% avatars and status dots. Nothing is
fully pill-shaped.

**Transparency and blur** are used twice, both functional: the sticky header scrim, and
`rgba(255,255,255,.08)` as the tab-group well on navy. Borders on navy are `rgba(255,255,255,.12)`
(dividers) and `.16` (avatar rings). No frosted-glass cards, no protection gradients over imagery
— there is no imagery to protect.

**Motion is short and unshowy.** Durations: .12s transform, .15s colour/border, .18s row
background, .3s state fade. Easing is plain `ease` except the one long move in the system — the
MedWatch page scrolling itself, 1.1s `cubic-bezier(.4,0,.2,1)`. **Hover:** buttons lift
`translateY(-1px)` (never change colour); links go navy → deep gold; product rows fill with
`#FBFBF9`. **Press:** nothing shrinks, nothing bounces — the state is simply the hover state
without the lift. Three product keyframes exist and are named in `tokens/motion.css`: `wb-bar`
(mic level), `wb-scan` (yellow sweep down the form while fields are written), `wb-ring` (one
expanding yellow ring, twice, when a draft completes).

**Imagery.** Cool, desaturated, and rare: two founder headshots (56px circles on navy) and two
greyscale scans of real FDA forms sitting in a slate well. No stock photography, no gradients
behind text, no b&w grain treatment — because there is nothing to treat.

**Hit targets** never go below 44px, including inline text links that carry `min-height: 44px`
while looking like plain type.

---

## ICONOGRAPHY

- **The set is Lucide 1.27.0**, bundled by the site itself and copied here verbatim to
  `assets/vendor/lucide.min.js`. Draw the same way the site does: render
  `<i data-lucide="name">` and call `lucide.createIcons()` — the `Icon` component wraps this.
  CDN equivalent if you prefer: `https://unpkg.com/lucide@1.27.0/dist/umd/lucide.min.js`.
  No substitution was needed; this is the real set.
- **The site uses exactly three glyphs**: `shield-off` (the "We keep nothing." promise),
  `arrow-right` (every row CTA), `mail` (the contact address). That is the whole inventory —
  iconography is informational, never decorative, and never rows of feature icons.
- **Sizes**: 15px inline in a link, 18px beside the contact address, 19px inside a 38px navy
  square with a yellow glyph (`--radius-lg`). Stroke weight is Lucide's default; do not thicken it.
- **No icon font, no sprite sheet, no custom SVG library.** The only bespoke vector art in the
  brand is the warbler mark itself (a flat four-colour PNG, `assets/logo-warbler-mark.png`).
- **Unicode stands in for two marks**, deliberately: `✓` as the checkmark written onto form
  checkboxes and inside the completion badge, and `▏` as the typing caret while the narrative
  writes itself. `·` (middle dot) separates metadata everywhere.
- **Emoji: never.** Not in UI, not in copy, not in headings.

---

## Components

React primitives, grouped by concern. Each directory holds `<Name>.jsx`, `<Name>.d.ts`,
`<Name>.prompt.md`, and one card HTML showing its states. Import via
`window.WarblerSafetyDesignSystem_192289`. Every family here has a counterpart in the source — the
site is hand-written inline styles, so the families were derived from patterns that recur in it.

**`components/brand/`** — Logo, Eyebrow, SectionHeading, Pullquote
**`components/core/`** — Button, TextLink, Icon, TabSwitch, ProgressBar
**`components/forms/`** — FieldLabel, TextField, SelectField, TextArea
**`components/content/`** — ProductRow, NumberedStep, NoticeCard, PersonCard
**`components/voice/`** — ChatBubble, MicMeter, DoneToast

| Component | Use it for |
| --- | --- |
| `Logo` | The mark + "Warbler Safety" lockup, where only the second word takes colour |
| `Eyebrow` | The tracked uppercase label that opens a section (the system's only uppercase) |
| `SectionHeading` | Display headings at the three sizes the site uses (h1 / lead / h2) |
| `Pullquote` | One claim per page, behind a 3px yellow rule |
| `Button` | The single filled action in a region — navy on light, yellow on navy |
| `TextLink` | Nav, footer, the big mailto, and every row CTA with a trailing arrow |
| `Icon` | Lucide glyphs, drawn the site's way |
| `TabSwitch` | Choosing between the Lucy and Wilson experiences |
| `ProgressBar` | Elapsed progress through a call, filled in deep gold |
| `FieldLabel` | 13px semibold label + control + optional fine-print hint |
| `TextField` / `SelectField` / `TextArea` | Cream-filled inputs with the navy focus ring |
| `ProductRow` | One product on a hairline; `state="upcoming"` drains its colour |
| `NumberedStep` | One of three "what happens next" steps with a gold 01/02/03 |
| `NoticeCard` | A promise (privacy, independence) with a navy icon square |
| `PersonCard` | A founder on navy: 56px photo, yellow role line |
| `ChatBubble` | A transcript turn — yellow for the agent, neutral for the person |
| `MicMeter` | The four-bar listening indicator in a 34px square |
| `DoneToast` | "Draft 3500A complete — 9 fields, 0 missing", handing review back |

**Intentional additions** (no direct counterpart in the source, added because the system needs them):
`Icon` — a wrapper around the site's `data-lucide` + `createIcons()` mechanism, so consumers do not
re-implement it; `FieldLabel` — the label/control/hint pattern the three form fields share, factored
out once.

## UI kits

| Kit | What it recreates |
| --- | --- |
| **`ui_kits/website/`** | warblersafety.com end to end — sticky header, hero, navy live-demo band, "after the call" steps, product rows, mission with citations, founders on navy, contact form, legal footer. Nav scrolls, tabs switch, the form submits. |
| **`ui_kits/voice_intake/`** | The Lucy / Wilson intake surface: transcript on the left, the real MedWatch form filling itself in on the right, with the shipped timings, field coordinates and narrative text. Play / pause / replay. |

Each kit has its own `README.md` with a file-by-file map and the behaviour rules worth preserving.

## Templates

`templates/marketing-page/` — a blank-slate Warbler page (header, hero, section shells, footer)
for building a new marketing or explainer page in the brand.

## Foundations (Design System tab)

29 specimen cards live under `guidelines/foundations/` and each component directory, grouped as
**Colors** (brand core, product accents, text ramp, light surfaces, navy section, lines),
**Type** (display, body, eyebrow, fine print, pairing), **Spacing** (scale, fluid rhythm, measures,
hit targets), **Shape** (radii, elevation), **Motion** (hover/press, product keyframes),
**Brand** (the warbler, MedWatch paper, iconography), **Components**, **Website**, **Voice intake**.

## Index of this folder

| Path | What it is |
| --- | --- |
| `styles.css` | The one file consumers link. `@import`s only. |
| `tokens/colors.css` | Base palette + semantic aliases, every value from the site |
| `tokens/typography.css` | Both families, weights, and the literal type scale |
| `tokens/spacing.css` | Fixed steps, `clamp()` rhythm, measures, 44px hit target |
| `tokens/shape.css` | Radii, border widths, the three shadows, focus ring, header blur |
| `tokens/motion.css` | Durations, easings, hover/press transitions, `wb-*` keyframes |
| `tokens/fonts.css` | `@font-face` for the bundled Hanken / Schibsted woff2 subsets |
| `tokens/base.css` | Element defaults and the `.wb-*` interaction classes |
| `assets/` | Warbler mark, favicon mark, founder photos, MedWatch scans, fonts, Lucide |
| `components/` | The 19 primitives above |
| `ui_kits/` | The two product recreations |
| `templates/` | Starting folders for new work in the brand |
| `guidelines/foundations/` | Specimen cards |
| `_source/` | The two unpacked upstream page sources — provenance, not shipped |
| `github.md` | Upstream repo association + screen map for syncing |
| `SKILL.md` | Agent Skills front-matter so this folder works in Claude Code |

## Gaps and cautions

- **No dark mode.** The site has dark *sections*, not a dark theme. Do not synthesise one.
- **No mobile app, no logged-in product, no dashboard, no email templates, no data viz, no
  empty/error/loading states** exist in the sources. Anything of that kind would be invention.
- **Magnolia has no visual design** beyond a muted row. Leave it that way.
- **Fonts are the real files** (Google Fonts woff2 as bundled by the site): latin, latin-ext, plus
  vietnamese and cyrillic-ext for Hanken Grotesk. Other scripts are not covered — if you need
  them, pull the fuller subsets from Google Fonts.
- **The mark is a raster PNG** (896×832, transparent). There is no vector logo in the sources, so
  it does not scale past ~450px cleanly and cannot be recoloured. A real SVG would be worth adding.
- The site's own inline `--md-*` variables (e.g. `--md-accent`) were used to theme the embedded
  demo; this system replaces them with `--accent`, `--surface-*` and `--border-*` tokens.
